

	public class Node {
		
		public String record;
		public Node next = null;

	}


