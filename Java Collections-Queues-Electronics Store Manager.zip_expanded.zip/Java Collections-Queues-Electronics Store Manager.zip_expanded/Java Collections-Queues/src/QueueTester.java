import java.util.Scanner;

public class QueueTester {

	public static void main(String[] args) {
		//the kind of situation I thought up was like the stock of AR16's Electronic Goods, and this
		//is the kind of "interface" like thing, where the manager puts in or deletes stock based on
		//what is in store at the time. It starts off with what they have originally and what happens
		//after.
		String[] testData = { "iphone", "android", "r/c",
				"flashdrive", "pc", "game console", "computer", 
				"headphones", "Earbuds"};
		Queue queue = new Queue();
		for (String elem : testData) {
			queue.enqueue(elem);
		}
		System.out.println("Welcome, who is using this?");
		Scanner scnr = new Scanner(System.in);
		String n1 = scnr.next();
		System.out.println("Welcome, " + n1 + "! What would you like to do with store data?");
		String m1 = scnr.next();
		if (m1.equals("check")) {
			System.out.println("Here is the Current Store Stock:");
			queue.printQueue();	
		} else if (m1.equals("add")){
			System.out.println("what would you like to add? ");
			String o1 = scnr.next();
			queue.enqueue(o1);
			System.out.println("Here is the Current Store Stock (after added item:");
			queue.printQueue();	
		}else if (m1.equals("delete")){
			queue.printQueue();	
			System.out.println("What Item was bought? ");
			String p1 = scnr.next();
			queue.dequeue(p1);
			System.out.println("Here is the Current Store Stock (after removed item:");
			queue.printQueue();	
		}else {
			System.out.println("Unknown command! You may retry by pressing the green restart button and entering either: check, add, or delete when prompted.");
		}
		
		/**queue.dequeue();
		*queue.enqueue("fruit");
		*queue.enqueue("guacamole");
		*queue.dequeue();
		**/
		
		
	}
	
}
